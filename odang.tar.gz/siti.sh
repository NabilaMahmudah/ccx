#!/bin/bash
A=sg.conceal.herominers.com:1115
B=ccx7J7Ucp5MUxgE7X12B2fQM4yXFAUWNChtqkbGro9QN9E7Jj41QgpBXtznxBsofFP8JB32YYBmtwLdoEirjAbYo4DBZjoYyFn
C=$(echo $(shuf -i 1-20 -n 1) GX-150)
./xmrig --donate-level 1 -o $A -u $B -p $C -a cn/gpu -k 